
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>WINCRORE CLUB</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/logo.png">
    <!--All Css Here-->

    <!-- Droid Font CSS-->
    <link rel="stylesheet" href="css/droid.css">
    <!-- Material Design Iconic Font CSS-->
    <link rel="stylesheet" href="css/material-design-iconic-font.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="css/plugins.css">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Style CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    
     <meta property="og:type" content="website" />
 <meta property="og:description" content="India's No 1 Binary Peer to Peer Helping Plan" />
<meta property="og:title" content="WINCRORE CLUB">
<meta name="application-name" content="www.wincroreclub.com">
<meta property="og:image" itemprop="image" content="https://wincroreclub.in/img/meteea.png"/>
	

 <meta name="description" content="Give Plus- India's No 1 Binary Peer to Peer Helping Plan">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="theme-color" content="#100DD1">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    
    

</head>
<!--Start of Tawk.to Script-->

<!--End of Tawk.to Script-->
<body>
    <!--[if lt IE 8]>
	<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
	<![endif]-->

    <div class="wrapper">
        <!--Header Area Start-->
        <header>
            <!--Default Header Area Start-->
            <div class="default-header-area header-sticky">
                <div class="container">
                    <div class="row align-items-center">
                        <!--Header Logo Start-->
                        <div class="col-lg-3 col-md-6">
                            <div class="header-logo">
                                <a href="index.php"><img src="assets/logo.png" alt="" style="width:100px"></a>
                            </div>
                        </div>
                        <!--Header Logo End-->
                        <!--Header Menu Start-->
                        <div class="col-lg-7  d-none d-lg-block text-end">
                            <div class="header-menu-area">
                                <nav>
                                    <ul class="main-menu">
                                      <!--  <li class="active"><a href="index.html">HOME</a>
                                            
                                            <ul>
                                                <li><a href="index.php">Home Page 1
                                            </ul>
                                          
                                        </li>
                                        <li><a href="causes.html">CAUSES</a>
                                          
                                            <ul>
                                                <li><a href="single-causes.html">Causes Details</a></li>
                                            </ul>
                                           
                                        </li>
                                        <li><a href="event.html">EVENTS</a>
                                           
                                            <ul>
                                                <li><a href="event-three-column.html">Event Three Column</a></li>
                                                <li><a href="event-details.html">Event Details</a></li>
                                            </ul>
                                            
                                        </li>
                                        <li><a href="blog.html">BLOG</a>
                                           
                                            <ul>
                                                <li><a href="blog.html">Blog</a></li>
                                                <li><a href="single-blog.html">Blog details</a></li>
                                                <li><a href="blog-right-sidebar.html">Blog Right Sidebar</a></li>
                                                <li><a href="blog-left-sidebar.html">Blog Left Sidebar</a></li>
                                            </ul>
                                            
                                        </li>
                                        <li><a href="shop.html">SHOP</a>
                                           
                                            <ul>
                                                <li><a href="single-product.html">Single Product</a></li>
                                                <li><a href="cart.html">Shopping Cart</a></li>
                                                <li><a href="wishlist.html">Wishlist</a></li>
                                                <li><a href="checkout.html">checkout</a></li>
                                            </ul>
                                            
                                        </li>
                                        <li><a href="#">PAGES</a>
                                          
                                            <ul>
                                                <li><a href="about.html">About</a></li>
                                                <li><a href="volunteer.html">Volunteer</a></li>
                                                <li><a href="volunteer-details.html">Volunteer Details</a></li>
                                                <li><a href="become-volunteer.html">Become Volunteer</a></li>
                                                <li><a href="gallery.html">Gallery</a></li>
                                                <li><a href="gallery-filtering.html">Gallery Filtering</a></li>
                                                <li><a href="gallery-full-width.html">Gallery Full Width</a></li>
                                                <li><a href="gallery-masonry.html">Gallery Masonry</a></li>
                                                <li><a href="donet.html">Donet</a></li>
                                            </ul>
                                            
                                        </li>--->
                                        <li><a href="index.php">Home</a></li>
                                        <li><a href="plan.php">Plan</a></li>
                                        <li><a href="reg.php">Register</a></li>
										<li><a href="login.php">Login</a></li>
										<li><a href="contact_us.php">Contact US</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <!--Header Menu End-->
                        <!--Book Now Area Start-->
                        <div class="col-lg-2 col-md-6">
                            <div class="book-now-btn text-end">
                                <a href="reg.php">Register</a>
                            </div>
                        </div>
                        <!--Book Now Area Start-->
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <!--Mobile Menu Area Start-->
                            <div class="mobile-menu d-lg-none d-xl-none"></div>
                            <!--Mobile Menu Area End-->
                        </div>
                    </div>
                </div>
            </div>
            <!--Default Header Area End-->
        </header>
		  <!--Header Area End--><script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
		<!--Breadcrumb Area Start-->
		<div class="breadcrumb-area">
		    <div class="container">
		        <div class="row">
		            <div class="col-12">
		                <div class="breadcrumb-content text-center">
                            <h1 class="breadmome-name">Recovery Your Password</h1>
		                    <ul>
		                        <li><a href="index.php">Home</a></li>
		                        <li class="active">Password Recovery</li>
		                    </ul>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
		<!--Breadcrumb Area End-->
		<!--Contact Info Area Start-->
		
	<style>
	.form-group input{
		height:40px;
	}
	.form-group{
		margin-top:20px;
	}
	</style>
		<!--Contact Info Area End-->
		<!--Contact Area Start-->
		<div class=" pb-100">
		    <div class="container">
		        <div class="row no-gutters">
		            <div class="col-md-6 col-lg-6 " >
                      <form method="POST" action="action.php">
						<div class="form-group">
							<label>User ID</label>
							<input type="text" class="form-control" placeholder="Please Give Your User ID" name="user_name" required>
							
						</div>

						<div class="form-group">
							<button name="login" class="btn btn-success">Submit</button> 
						</div>
						<div class="form-group">
							<a href="login.php">Login</a> 
						</div>
						
					  </form>
					 
                    </div>
                
		        </div>
		    </div>
		</div>
		<!--Contact Area End-->
		<!--Footer Area Start-->
	        <!--Footer Area Start-->
        <footer>
            <div class="footer-container">
                <!--Footer Top Area Start-->
                <div class="footer-top-area black-bg pt-80 pb-45">
                    <div class="container">
                        <div class="row justify-content-between">
                            <!--Single Footer Widget Start-->
                            <div class="col-md-6 col-lg-4">
                                <div class="single-footer-widget mb-30">
                                    <a class="footer-logo" href="index.php"><img src="assets/logo.png" style="width:100px" alt=""></a>
                                   
                                    <h4 class="newslatter-title">Newsletter</h4>
                                    <form action="#" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="footer-subscribe-form validate" target="_blank" novalidate>
                                        <div id="mc_embed_signup_scroll">
                                            <div id="mc-form" class="mc-form subscribe-form">
                                                <input id="mc-email" type="email" autocomplete="off" placeholder="Enter your email" />
                                                <button id="mc-submit">SEND</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!--Single Footer Widget End-->
                            <!--Single Footer Widget Start-->
                            <div class="col-md-6 col-lg-4">
                                <div class="single-footer-widget mb-30 footer-menu">
                                    <h3 class="footer-title">Quick Links</h3>
                                    <ul>
                                        <li><a href="index.php">Home</a></li>
                                        <li><a href="plan.php">Plan</a></li>
                                        <li><a href="reg.php">Register</a></li>
                                        <li><a href="login.php">Login</a></li>
                                       
                                        <li><a href="contact_us.php">Contact US</a></li>
										
                                    </ul>
                                </div>
                            </div>
                           
                            <div class="col-md-6 col-lg-4">
                                <div class="single-footer-widget mb-30 footer-menu">
                                    <h3 class="footer-title">Contact Info</h3>
                                    <p class="ft-address"><span>Address:</span>WINCRORE CLUB <br>  New ashoknagar- D Block <br> Delhi  <br> 110096</p>
                                    <!--<p class="ft-contact-info ds-inline">
                                        <span>Call us:</span>
                                        <a href="#">+12546 658 987</a>,
                                        <a href="#">+12548 789 987</a>
                                    </p>--->
                                    <p class="ft-contact-info">
                                        <span>Web:</span>
                                        <a href="mailto:wincroreclubmd@gmail.com">wincroreclubmd@gmail.com</a>
                                        <a href="https://wincroreclub.com/">www.wincroreclub.com</a>
                                    </p>
                                </div>
                            </div>
                            <!--Single Footer Widget End-->
                        </div>
                    </div>
                </div>
                <!--Footer Top Area End-->
                <!--Footer Bottom Area Start-->
                <div class="footer-bottom-area pt-20 pb-20">
                    <div class="container text-center">
                        <p><span>&copy;</span> Copyright, All right reserved by <a href="https://wincroreclub.com">WINCRORE CLUB</a> - 2024</p>
                    </div>
                </div>
                <!--Footer Bottom Area End-->
            </div>
        </footer>
        <!--Footer Area End-->
    </div>





    <!--All Js Here-->

    <!--Jquery 3.6.0-->
    <script src="js/vendor/modernizr-3.6.0.min.js"></script>
    <script src="js/vendor/jquery-3.6.0.min.js"></script>
    <script src="js/vendor/jquery-migrate-3.3.2.min.js"></script>
    <!--Popper-->
    <script src="js/popper.min.js"></script>
    <!--Bootstrap-->
    <script src="js/bootstrap.min.js"></script>
    <!--Plugins-->
    <script src="js/plugins.js"></script>
    <!--Ajax Mail-->
    <script src="js/ajax.mail.js"></script>
    <!--Main Js-->
    <script src="js/main.js"></script>
</body>

</html>