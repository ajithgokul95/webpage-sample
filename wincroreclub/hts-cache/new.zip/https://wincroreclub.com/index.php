
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>WINCRORE CLUB</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/logo.png">
    <!--All Css Here-->

    <!-- Droid Font CSS-->
    <link rel="stylesheet" href="css/droid.css">
    <!-- Material Design Iconic Font CSS-->
    <link rel="stylesheet" href="css/material-design-iconic-font.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="css/plugins.css">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Style CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    
     <meta property="og:type" content="website" />
 <meta property="og:description" content="India's No 1 Binary Peer to Peer Helping Plan" />
<meta property="og:title" content="WINCRORE CLUB">
<meta name="application-name" content="www.wincroreclub.com">
<meta property="og:image" itemprop="image" content="https://wincroreclub.in/img/meteea.png"/>
	

 <meta name="description" content="Give Plus- India's No 1 Binary Peer to Peer Helping Plan">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="theme-color" content="#100DD1">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    
    

</head>
<!--Start of Tawk.to Script-->

<!--End of Tawk.to Script-->
<body>
    <!--[if lt IE 8]>
	<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
	<![endif]-->

    <div class="wrapper">
        <!--Header Area Start-->
        <header>
            <!--Default Header Area Start-->
            <div class="default-header-area header-sticky">
                <div class="container">
                    <div class="row align-items-center">
                        <!--Header Logo Start-->
                        <div class="col-lg-3 col-md-6">
                            <div class="header-logo">
                                <a href="index.php"><img src="assets/logo.png" alt="" style="width:100px"></a>
                            </div>
                        </div>
                        <!--Header Logo End-->
                        <!--Header Menu Start-->
                        <div class="col-lg-7  d-none d-lg-block text-end">
                            <div class="header-menu-area">
                                <nav>
                                    <ul class="main-menu">
                                      <!--  <li class="active"><a href="index.html">HOME</a>
                                            
                                            <ul>
                                                <li><a href="index.php">Home Page 1
                                            </ul>
                                          
                                        </li>
                                        <li><a href="causes.html">CAUSES</a>
                                          
                                            <ul>
                                                <li><a href="single-causes.html">Causes Details</a></li>
                                            </ul>
                                           
                                        </li>
                                        <li><a href="event.html">EVENTS</a>
                                           
                                            <ul>
                                                <li><a href="event-three-column.html">Event Three Column</a></li>
                                                <li><a href="event-details.html">Event Details</a></li>
                                            </ul>
                                            
                                        </li>
                                        <li><a href="blog.html">BLOG</a>
                                           
                                            <ul>
                                                <li><a href="blog.html">Blog</a></li>
                                                <li><a href="single-blog.html">Blog details</a></li>
                                                <li><a href="blog-right-sidebar.html">Blog Right Sidebar</a></li>
                                                <li><a href="blog-left-sidebar.html">Blog Left Sidebar</a></li>
                                            </ul>
                                            
                                        </li>
                                        <li><a href="shop.html">SHOP</a>
                                           
                                            <ul>
                                                <li><a href="single-product.html">Single Product</a></li>
                                                <li><a href="cart.html">Shopping Cart</a></li>
                                                <li><a href="wishlist.html">Wishlist</a></li>
                                                <li><a href="checkout.html">checkout</a></li>
                                            </ul>
                                            
                                        </li>
                                        <li><a href="#">PAGES</a>
                                          
                                            <ul>
                                                <li><a href="about.html">About</a></li>
                                                <li><a href="volunteer.html">Volunteer</a></li>
                                                <li><a href="volunteer-details.html">Volunteer Details</a></li>
                                                <li><a href="become-volunteer.html">Become Volunteer</a></li>
                                                <li><a href="gallery.html">Gallery</a></li>
                                                <li><a href="gallery-filtering.html">Gallery Filtering</a></li>
                                                <li><a href="gallery-full-width.html">Gallery Full Width</a></li>
                                                <li><a href="gallery-masonry.html">Gallery Masonry</a></li>
                                                <li><a href="donet.html">Donet</a></li>
                                            </ul>
                                            
                                        </li>--->
                                        <li><a href="index.php">Home</a></li>
                                        <li><a href="plan.php">Plan</a></li>
                                        <li><a href="reg.php">Register</a></li>
										<li><a href="login.php">Login</a></li>
										<li><a href="contact_us.php">Contact US</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <!--Header Menu End-->
                        <!--Book Now Area Start-->
                        <div class="col-lg-2 col-md-6">
                            <div class="book-now-btn text-end">
                                <a href="reg.php">Register</a>
                            </div>
                        </div>
                        <!--Book Now Area Start-->
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <!--Mobile Menu Area Start-->
                            <div class="mobile-menu d-lg-none d-xl-none"></div>
                            <!--Mobile Menu Area End-->
                        </div>
                    </div>
                </div>
            </div>
            <!--Default Header Area End-->
        </header>
		  <!--Header Area End-->      
        <!--Slider Area Start-->
        <div class="slider-area">
            <div class="hero-slider owl-carousel">
                <!--Single Slider Start-->
                <div class="single-slider" style="background-image: url(https://www.success.com/wp-content/uploads/2017/07/waystohelpyourselfandothersbesuccessful-1-1024x682.jpg)">
                    <div class="container">
                        <div class="row">
                            <div class="col-12">
                                <div class="hero-slider-content">
                                    <h1>Give Plus. Get Bless</h1>
									<div class="slider-btn">
                                        <a class="default-btn" href="reg.php">Register </a>
                                    </div>
                                  
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Single Slider End-->
                <!--Single Slider Start-->
                <!--<div class="single-slider" style="background-image: url(img/slider/slide1-home-1.jpg)">
                    <div class="container">
                        <div class="row">
                            <div class="col-12">
                                <div class="hero-slider-content">
                                    <h1>Let's teach them letter, the world will be better</h1>
                                    <div class="slider-btn">
                                        <a class="default-btn" href="#">READ MORE</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>--->
                <!--Single Slider End-->
            </div>
        </div>
        <!--Slider Area End-->
        <!--Feature Area Start-->
        <div class="feature-area fix mb-10">
            <div class="container-fluid p-0">
                <div class="row coustom-row">
                    <div class="single-feature col-md-4">
                        <!--Single Feature Area Start-->
                        <div class="single-feature-inner">
                            <h2>Register Free , And we Don't your Account Block . If you dont provide help you can reject the get help..</h2>
                        </div>
                        <!--Single Feature Area End-->
                    </div>
                    <div class="single-feature col-md-4">
                        <!--Single Feature Area Start-->
                        <div class="single-feature-inner">
                            <h2>India's First Sponsor with Peer to Peer Helping platform, Your ID Amount 100 Rs Retrun to Income</h2>
                        </div>
                        <!--Single Feature Area End-->
                    </div>
                    <div class="single-feature col-md-4">
                        <!--Single Feature Area Start-->
                        <div class="single-feature-inner">
                            <h2>Give Help only 500 Rs.. And  Id Activation 100 Rs. Total 600 Rs</h2>
                        </div>
                        <!--Single Feature Area End-->
                    </div>
                </div>
            </div>
        </div>
        <!--Feature Area End-->
        <!--Service Area Start-->
        <div class="service-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7">
                        <div class="row">
                            <div class="col-12">
                                <div class="service-section-title mb-40">
                                    <h2>About Us</h2>
                                   
                                    <p>Welcome to WINCRORE CLUB . When you WINCRORE CLUB you will Get Bless. We are set the platform of peer to peer helping plan with binary system. It have use to grow your life like millionaire. Only one rupee per day of Investment
 </p>
                                </div>
                            </div>
                        </div>
                        <!--<div class="row">
                            <div class="col-md-6">
                                
                                <div class="single-service mb-30">
                                    <h2 class="service-title">Make Donation</h2>
                                    <p>Pursue pleasure rationally counter consequences that are extremely painful. Nor again is here</p>
                                </div>
                               
                            </div>
                            <div class="col-md-6">
                                
                                <div class="single-service mb-30">
                                    <h2 class="service-title">Give Scholarship</h2>
                                    <p>Pursue pleasure rationally counter consequences that are extremely painful. Nor again is here</p>
                                </div>
                               
                            </div>
                            <div class="col-md-6">
                               
                                <div class="single-service mb-30">
                                    <h2 class="service-title">Become a Volunteer</h2>
                                    <p>Pursue pleasure rationally counter consequences that are extremely painful. Nor again is here</p>
                                </div>
                               
                            </div>
                            <div class="col-md-6">
                                
                                <div class="single-service mb-30">
                                    <h2 class="service-title">Organize Entertainment</h2>
                                    <p>Pursue pleasure rationally counter consequences that are extremely painful. Nor again is here</p>
                                </div>
                               
                            </div>
                            <div class="col-md-6">
                               
                                <div class="single-service mb-30">
                                    <h2 class="service-title">Food & Water Supply</h2>
                                    <p>Pursue pleasure rationally counter consequences that are extremely painful. Nor again is here</p>
                                </div>
                               
                            </div>
                            <div class="col-md-6">
                                
                                <div class="single-service mb-30">
                                    <h2 class="service-title">Protect Environment</h2>
                                    <p>Pursue pleasure rationally counter consequences that are extremely painful. Nor again is here</p>
                                </div>
                              
                            </div>
                        </div>----->
                    </div>
                </div>
            </div>
            <div class="service-image">
                <img src="img/about.png" alt="" style="height:300px;width:300px">
            </div>
        </div>
        <!--Service Area End-->
        <!--Our Causes Area Start-->
        <div class="our-causes-area pt-115">
            <div class="container">
               <!-- <div class="row">
                    <div class="col-122">
                        <iframe width="100%" height="315" src="https://www.youtube.com/embed/0EjX1p9jP9I" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
					<div class="col-12">
                        
                        <div class="section-title mb-60">
                            <h2>Type Of Income</h2>
                            <p>Give Plus... Get Bless</p>
                        </div>
                       
                    </div>
                </div>--->
                <div class="row">
                    <!--Single Causes Area Start-->
                    <!--<div class="col-lg-6 col-xl-3 col-md-6">
                        <div class="single-causes-area mb-30">
                            <div class="causes-feature">
                                <ul>
                                    <li><span class="content">Raised</span> <span class="per-count">$10,000</span></li>
                                    <li><span class="content">Achive</span> <span class="per-count">50.5%</span></li>
                                    <li><span class="content">Goal</span> <span class="per-count">$18,000</span></li>
                                </ul>
                            </div>
                            <div class="causes-img img-full">
                                <a href="single-causes.html"><img src="img/causes/causes1.jpg" alt=""></a>
                            </div>
                            <div class="casues-content">
                                <h3><a href="single-causes.html">Education.</a></h3>
                                <p>Pursue pleasure rationally unter consequences that are tremely painful. Nor again is here</p>
                            </div>
                        </div>
                    </div>--->
                    <!--Single Causes Area End-->
                    <!--Single Causes Area Start-->
					<style>
					ul{
						margin:10px;
					}
					</style>
                    <div class="col-lg-4 col-xl-4 col-md-4 col-xs-12">
                        <div class="single-causes-area mb-30">
                          
                            <div class="causes-img img-full">
                                <a href="single-causes.html"><img src="img/1.jpg" alt=""></a>
                            </div>
                            <div class="casues-content">
                                <h3><a href="reg.php">Referral Income</a></h3>
                                <ul>
								<li>We offer best autopool system With Referral Income</li>
								<li>Referral income 500 Rs Per ID</li>
								
								<li>Complete 6 nd Level You will Eligible Referral income 35,445,00 Rs</li>
								</ul>
                            </div>
                        </div>
                    </div>
					<div class="col-lg-4 col-xl-4 col-md-4 col-xs-12">
                        <div class="single-causes-area mb-30">
                          
                            <div class="causes-img img-full">
                                <a href="single-causes.html"><img src="img/2.png" alt=""></a>
                            </div>
                            <div class="casues-content">
                                <h3><a href="reg.php">Get Help income
</a></h3>
                                 <ul>
								<li>Here Autobot system concept of Get help and Provide Help.</li>
								<li> So you do not waiting for get help .</li>
								<li>Autopool Get help income Rs.533182500
</li>
								</ul>
                            </div>
                        </div>
                    </div>
					<div class="col-lg-4 col-xl-4 col-md-4 col-xs-12">
                        <div class="single-causes-area mb-30">
                          
                            <div class="causes-img img-full">
                                <a href="reg.php"><img src="img/3.jpg" alt=""></a>
                            </div>
                            <div class="casues-content">
                                <h3><a href="#">Rewards Award</a></h3>
                                 <ul>
								<li>Company Will Provide Exiting 
                                    Gifts
                                </li>
                                <li>This Gifts based on Physical Products</li>
                                <li>Gift value more than 200000 Rs</li>
								</ul>
                            </div>
                        </div>
                    </div>
                    <!--Single Causes Area End-->
                 
                </div>
            </div>
        </div>
        <!--Our Causes Area End-->
        <!--Donate Product Area Start
        <div class="donate-product-area pt-60">
            <div class="container coustom-container">
                <div class="row coustom-row-two">
                    <div class="col-lg-5 col-xl-6 col-50">
                        <div class="donation-image">
                            <img src="img/donate/donrt1.png" alt="">
                        </div>
                    </div>
                    <div class="col-lg-7 col-xl-6 col-70">
                        <div class="donet-product">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="donet-shop">
                                        <h2>Product for <br> Humanity</h2>
                                        <p>Pursue pleasure rationally encounter consequences that extremely pain again</p>
                                        <a href="#">SHOP NOW</a>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="single-donet-product">
                                        <img src="img/donate/donet-product1.png" alt="">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="single-donet-product">
                                        <img src="img/donate/donet-product2.png" alt="">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="single-donet-product">
                                        <img src="img/donate/donet-product3.png" alt="">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="single-donet-product">
                                        <img src="img/donate/donet-product4.png" alt="">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="single-donet-product">
                                        <img src="img/donate/donet-product5.png" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Donate Product Area End-->
        <!--Event Area Start
        <div class="event-area pt-70">
            <div class="container">
                <div class="row align-items-center">
                   
                    <div class="col-lg-6 col-12">
                        <div class="event-slider">
                           
                            <div class="single-event">
                                <div class="event-img img-full">
                                    <img src="img/event/event1.jpg" alt="">
                                </div>
                                <div class="event-content">
                                    <h3><a href="event-details.html">Medical Camp for Poor Children</a></h3>
                                    <p>Central Hall, California. 25 Oct, 2018 at 10 am</p>
                                </div>
                            </div>
                           
                            <div class="single-event">
                                <div class="event-img img-full">
                                    <img src="img/event/event2.jpg" alt="">
                                </div>
                                <div class="event-content">
                                    <h3><a href="event-details.html">Pure Drinking Water for helpless people</a></h3>
                                    <p>Midland Cricket Ground. 25 Oct, 2018 at 10 am</p>
                                </div>
                            </div>
                            
                            <div class="single-event">
                                <div class="event-img img-full">
                                    <img src="img/event/event3.jpg" alt="">
                                </div>
                                <div class="event-content">
                                    <h3><a href="event-details.html">Medical Camp for Poor Children</a></h3>
                                    <p>Central Hall, California. 25 Oct, 2018 at 10 am</p>
                                </div>
                            </div>
                            
                            <div class="single-event">
                                <div class="event-img img-full">
                                    <img src="img/event/event4.jpg" alt="">
                                </div>
                                <div class="event-content">
                                    <h3><a href="event-details.html">Pure Drinking Water for helpless people</a></h3>
                                    <p>Midland Cricket Ground. 25 Oct, 2018 at 10 am</p>
                                </div>
                            </div>
                           
                            <div class="single-event">
                                <div class="event-img img-full">
                                    <img src="img/event/event5.jpg" alt="">
                                </div>
                                <div class="event-content">
                                    <h3>Medical Camp for Poor Children</h3>
                                    <p>Central Hall, California. 25 Oct, 2018 at 10 am</p>
                                </div>
                            </div>
                           
                        </div>
                    </div>
                   
                    <div class="col-lg-6 col-12 pl-60">
                        
                        <div class="section-title text-left">
                            <h2>Our Causes</h2>
                        </div>
                        
                        <div class="event-description">
                            <h4>You can know about our latest and upcoming events information clearly...</h4>
                            <p>Pursue pleasure rationally encounter consequences that treme painful. Nor again is there anyone obtain pain of itself, because it is pain, but because occasionally circumstances occue</p>
                            <p>Events are pleasure rationally encounter consequences that treme painful. Nor again is there anyone obtain pain </p>
                            <a class="default-btn" href="#">KNOW MORE</a>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        <!--Event Area End-->
        <!--Fun Factor Area Start-->
        <div class="fun-factor-area fun-bg mt-100">
            <div class="container">
                <div class="row justify-content-between content-between">
                    <div class="col">
                        <div class="single-funfactor mb-30 text-center">
                            <div class="fun-facttor-number">
                                <h2><span class="counter">1280</span></h2>
                            </div>
                            <h4 class="counter-title">Successful Projects</h4>
                        </div>
                    </div>
                    <div class="col">
                        <div class="single-funfactor mb-30 text-center">
                            <div class="fun-facttor-number">
                                <h2><span class="counter">1052</span></h2>
                            </div>
                            <h4 class="counter-title">Total Sponsor</h4>
                        </div>
                    </div>
                    <div class="col">
                        <div class="single-funfactor mb-30 text-center">
                            <div class="fun-facttor-number">
                                <h2>Rs<span class="counter">280</span>m</h2>
                            </div>
                            <h4 class="counter-title">Money Donated</h4>
                        </div>
                    </div>
                    <div class="col">
                        <div class="single-funfactor mb-30 text-center">
                            <div class="fun-facttor-number">
                                <h2><span class="counter">3298</span></h2>
                            </div>
                            <h4 class="counter-title">Total Volunteers</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Fun Factor Area End-->
        <!--Testimonial Area Start
        <div class="testimonial-area pt-100">
            <div class="container">
                <div class="row testimonial-active">
                    <div class="col-6">
                       
                        <div class="single-testimonial">
                            <div class="testimonial-content">
                                <p>Pursue pleasure rationally encounter equences that treme painful. Nor again is there anyone obtain pain of itself, because it is pain</p>
                            </div>
                            <div class="testimonial-author-info">
                                <div class="team-author-deg">
                                    <h3>Stephen Smith</h3>
                                    <p>Donetor, CEO of Axion</p>
                                </div>
                                <div class="author-img">
                                    <img src="img/testimonial/testi1-home-1.jpg" alt="">
                                </div>
                            </div>
                        </div>
                       
                    </div>
                    <div class="col-6">
                      
                        <div class="single-testimonial">
                            <div class="testimonial-content">
                                <p>Pursue pleasure rationally encounter equences that treme painful. Nor again is there anyone obtain pain of itself, because it is pain</p>
                            </div>
                            <div class="testimonial-author-info">
                                <div class="team-author-deg">
                                    <h3>Jeniger Hearly</h3>
                                    <p>Donetor, CEO of Axion</p>
                                </div>
                                <div class="author-img">
                                    <img src="img/testimonial/testi2-home-1.jpg" alt="">
                                </div>
                            </div>
                        </div>
                      
                    </div>
                    <div class="col-6">
                       
                        <div class="single-testimonial">
                            <div class="testimonial-content">
                                <p>Pursue pleasure rationally encounter equences that treme painful. Nor again is there anyone obtain pain of itself, because it is pain</p>
                            </div>
                            <div class="testimonial-author-info">
                                <div class="team-author-deg">
                                    <h3>Stephen Smith</h3>
                                    <p>Donetor, CEO of Axion</p>
                                </div>
                                <div class="author-img">
                                    <img src="img/testimonial/testi1-home-1.jpg" alt="">
                                </div>
                            </div>
                        </div>
                     
                    </div>
                    <div class="col-6">
                    
                        <div class="single-testimonial">
                            <div class="testimonial-content">
                                <p>Pursue pleasure rationally encounter equences that treme painful. Nor again is there anyone obtain pain of itself, because it is pain</p>
                            </div>
                            <div class="testimonial-author-info">
                                <div class="team-author-deg">
                                    <h3>Jeniger Hearly</h3>
                                    <p>Donetor, CEO of Axion</p>
                                </div>
                                <div class="author-img">
                                    <img src="img/testimonial/testi2-home-1.jpg" alt="">
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
            </div>
        </div>
        <!--Testimonial Area End-->
        <!--Our Blog Area Start
        <div class="our-blog-area pt-115">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                     
                        <div class="section-title mb-60">
                            <h2>Our Blog</h2>
                            <p>Pursue pleasure rationally encounter consequences that extremely painful. Nor again is there anyone who loves or pursues </p>
                        </div>
                        
                    </div>
                </div>
                <div class="row">
                
                    <div class="col-lg-6 col-xl-3 col-md-6">
                        <div class="single-blog mb-30">
                            <div class="blog-img img-full">
                                <a href="single-blog.html"><img src="img/blog/small/blog1.jpg" alt=""></a>
                            </div>
                            <div class="blog-content">
                                <ul class="meta">
                                    <li>By <a href="#">Jenifer</a></li>
                                    <li>25 Oct, 2018 </li>
                                </ul>
                                <h4 class="title"><a href="single-blog.html">Marathon compitition for fund rising</a></h4>
                                <a href="single-blog.html">Continue Reading</a>
                            </div>
                        </div>
                    </div>
                   
                    <div class="col-lg-6 col-xl-3 col-md-6">
                        <div class="single-blog mb-30">
                            <div class="blog-img img-full">
                                <a href="single-blog.html"><img src="img/blog/small/blog2.jpg" alt=""></a>
                            </div>
                            <div class="blog-content">
                                <ul class="meta">
                                    <li>By <a href="#">Jenifer</a></li>
                                    <li>12 Nov, 2018 </li>
                                </ul>
                                <h4 class="title"><a href="single-blog.html">Africa Children Need More Food</a></h4>
                                <a href="single-blog.html">Continue Reading</a>
                            </div>
                        </div>
                    </div>
                   
                    <div class="col-lg-6 col-xl-3 col-md-6">
                        <div class="single-blog mb-30">
                            <div class="blog-img img-full">
                                <a href="single-blog.html"><img src="img/blog/small/blog3.jpg" alt=""></a>
                            </div>
                            <div class="blog-content">
                                <ul class="meta">
                                    <li>By <a href="#">Jenifer</a></li>
                                    <li>15 Apr, 2018 </li>
                                </ul>
                                <h4 class="title"><a href="single-blog.html">Africa Children Water And Clothes</a></h4>
                                <a href="single-blog.html">Continue Reading</a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-6 col-xl-3 col-md-6">
                        <div class="single-blog mb-30">
                            <div class="blog-img img-full">
                                <a href="single-blog.html"><img src="img/blog/small/blog4.jpg" alt=""></a>
                            </div>
                            <div class="blog-content">
                                <ul class="meta">
                                    <li>By <a href="#">Jenifer</a></li>
                                    <li>25 Feb, 2018 </li>
                                </ul>
                                <h4 class="title"><a href="single-blog.html">Marathon compitition for fund rising</a></h4>
                                <a href="single-blog.html">Continue Reading</a>
                            </div>
                        </div>
                    </div>
                   
                </div>
            </div>
        </div>
        <!--Our Blog Area End-->
        <!--Project Area Start-->
        <div class="project-area pt-70 mb-5">
            <div class="container-fluid p-0">
                <div class="row no-gutters project-active owl-carousel">
                    <div class="col-12">
                        <!--Single Project Start-->
                        <div class="single-project img-full">
                            <a href="#"><img src="img/project/project1.jpg" alt=""></a>
                        </div>
                        <!--Single Project End-->
                    </div>
                    <div class="col-12">
                        <!--Single Project Start-->
                        <div class="single-project img-full">
                            <a href="#"><img src="img/project/project2.jpg" alt=""></a>
                        </div>
                        <!--Single Project End-->
                    </div>
                    <div class="col-12">
                        <!--Single Project Start-->
                        <div class="single-project img-full">
                            <a href="#"><img src="img/project/project3.jpg" alt=""></a>
                        </div>
                        <!--Single Project End-->
                    </div>
                    <div class="col-12">
                        <!--Single Project Start-->
                        <div class="single-project img-full">
                            <a href="#"><img src="img/project/project4.jpg" alt=""></a>
                        </div>
                        <!--Single Project End-->
                    </div>
                    <div class="col-12">
                        <!--Single Project Start-->
                        <div class="single-project img-full">
                            <a href="#"><img src="img/project/project5.jpg" alt=""></a>
                        </div>
                        <!--Single Project End-->
                    </div>
                </div>
            </div>
        </div>
        <!--Project Area End-->
        <!--Footer Area Start-->
        <footer>
            <div class="footer-container">
                <!--Footer Top Area Start-->
                <div class="footer-top-area black-bg pt-80 pb-45">
                    <div class="container">
                        <div class="row justify-content-between">
                            <!--Single Footer Widget Start-->
                            <div class="col-md-6 col-lg-4">
                                <div class="single-footer-widget mb-30">
                                    <a class="footer-logo" href="index.php"><img src="assets/logo.png" style="width:100px" alt=""></a>
                                   
                                    <h4 class="newslatter-title">Newsletter</h4>
                                    <form action="#" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="footer-subscribe-form validate" target="_blank" novalidate>
                                        <div id="mc_embed_signup_scroll">
                                            <div id="mc-form" class="mc-form subscribe-form">
                                                <input id="mc-email" type="email" autocomplete="off" placeholder="Enter your email" />
                                                <button id="mc-submit">SEND</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!--Single Footer Widget End-->
                            <!--Single Footer Widget Start-->
                            <div class="col-md-6 col-lg-4">
                                <div class="single-footer-widget mb-30 footer-menu">
                                    <h3 class="footer-title">Quick Links</h3>
                                    <ul>
                                        <li><a href="index.php">Home</a></li>
                                        <li><a href="plan.php">Plan</a></li>
                                        <li><a href="reg.php">Register</a></li>
                                        <li><a href="login.php">Login</a></li>
                                       
                                        <li><a href="contact_us.php">Contact US</a></li>
										
                                    </ul>
                                </div>
                            </div>
                           
                            <div class="col-md-6 col-lg-4">
                                <div class="single-footer-widget mb-30 footer-menu">
                                    <h3 class="footer-title">Contact Info</h3>
                                    <p class="ft-address"><span>Address:</span>WINCRORE CLUB <br>  New ashoknagar- D Block <br> Delhi  <br> 110096</p>
                                    <!--<p class="ft-contact-info ds-inline">
                                        <span>Call us:</span>
                                        <a href="#">+12546 658 987</a>,
                                        <a href="#">+12548 789 987</a>
                                    </p>--->
                                    <p class="ft-contact-info">
                                        <span>Web:</span>
                                        <a href="mailto:wincroreclubmd@gmail.com">wincroreclubmd@gmail.com</a>
                                        <a href="https://wincroreclub.com/">www.wincroreclub.com</a>
                                    </p>
                                </div>
                            </div>
                            <!--Single Footer Widget End-->
                        </div>
                    </div>
                </div>
                <!--Footer Top Area End-->
                <!--Footer Bottom Area Start-->
                <div class="footer-bottom-area pt-20 pb-20">
                    <div class="container text-center">
                        <p><span>&copy;</span> Copyright, All right reserved by <a href="https://wincroreclub.com">WINCRORE CLUB</a> - 2024</p>
                    </div>
                </div>
                <!--Footer Bottom Area End-->
            </div>
        </footer>
        <!--Footer Area End-->
    </div>





    <!--All Js Here-->

    <!--Jquery 3.6.0-->
    <script src="js/vendor/modernizr-3.6.0.min.js"></script>
    <script src="js/vendor/jquery-3.6.0.min.js"></script>
    <script src="js/vendor/jquery-migrate-3.3.2.min.js"></script>
    <!--Popper-->
    <script src="js/popper.min.js"></script>
    <!--Bootstrap-->
    <script src="js/bootstrap.min.js"></script>
    <!--Plugins-->
    <script src="js/plugins.js"></script>
    <!--Ajax Mail-->
    <script src="js/ajax.mail.js"></script>
    <!--Main Js-->
    <script src="js/main.js"></script>
</body>

</html>